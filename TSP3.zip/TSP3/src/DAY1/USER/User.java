package DAY1.USER;

public class User {
    private String name;
    private int token;

    public User(String name, int token) {
        this.name = name;
        this.token = token;
    }

    private void addOneToken() {
        token++;
    }

    private void removeOneToken(){
        token--;
    }

    public void addTokens(int number) {
        for(int i = 0; i < number; i++)
            addOneToken();
    }

    public void removeTokens(int number){
        for(int i = 0; i < number; i++)
            removeOneToken();
    }

    public void print(){
        if(token <= 0 || token == 1)
            System.out.println(name + " has insufficient funds");
        else
            removeTokens(2);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getToken() {
        return token;
    }

    public void setToken(int token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return name + " " + token;

    }

}
