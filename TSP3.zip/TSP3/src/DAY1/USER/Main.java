package DAY1.USER;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<User> users = new ArrayList<>();
        User user1 = new User("Daniel", 1);
        User user2 = new User("Henry", 2);
        User user3 = new User("Matt", 3);
        User user4 = new User("Devon", 4);
        User user5 = new User("Chuks", 5);

        users.add(user1);
        users.add(user2);
        users.add(user3);
        users.add(user4);
        users.add(user5);

        user1.print();
        System.out.println(user1.getName() + " has "+ user1.getToken() + " tokens.");

        for (int i =0; i<users.size(); i++) {
            System.out.println(users.get(i));
        }

    }
}
